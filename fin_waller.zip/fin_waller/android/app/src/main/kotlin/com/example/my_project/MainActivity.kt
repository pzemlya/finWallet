package com.newstep.finwallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
